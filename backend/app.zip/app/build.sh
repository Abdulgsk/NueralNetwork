pip install -r requirements.txt
app-get install build-essential